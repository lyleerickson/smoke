zip -qr getID.zip *
aws lambda update-function-code --function-name getID --zip-file fileb://getID.zip
aws lambda invoke --function-name getID --payload '{"1": "1"}' outfile
cat outfile
echo ""

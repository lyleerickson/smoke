aws lambda invoke --function-name getID --payload '{"1": "1"}' outfile
cat outfile
echo ""

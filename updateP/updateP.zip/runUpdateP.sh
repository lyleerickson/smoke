CMD="aws lambda invoke --function-name updateP --payload '{\"id\": \"$1\", \"name\": \"Updated Name\"}' outfile"
eval $CMD
cat outfile
echo ""

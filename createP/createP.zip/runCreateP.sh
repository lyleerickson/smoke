aws lambda invoke --function-name createP --payload file://infile outfile
cat outfile
echo ""
